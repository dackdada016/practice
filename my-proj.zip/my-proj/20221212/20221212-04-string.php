<?php

  $name = 'David';

  echo "Hello $name <br>"; // 會顯示變數
  echo "Hello ${name}123 <br>";
  echo "Hello {$name}123 <br>";
  echo 'Hello $name <br>'; // 不會顯示變數 只會顯示字串




?>