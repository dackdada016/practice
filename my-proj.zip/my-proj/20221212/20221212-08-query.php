<?php
// ?a=10&b=12;
// $_GET 內建的變數
echo $_GET['a'] + $_GET['b'];