<pre>

<?php
var_dump($_GET['a']);
?>
</pre>