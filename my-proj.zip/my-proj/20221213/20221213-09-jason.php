<pre>
<?php
    $ar1 = [
        'name' => 'Devid',
        'age' => 25,
    ];
    // 編碼成 Json 字串
    echo json_encode($ar1);
    // json_decode
    ?>
</pre>