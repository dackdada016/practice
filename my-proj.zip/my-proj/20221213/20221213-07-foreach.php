<pre>
<?php
    $ar5 = [
        'hello',
        'name' => 'Devid',
        'age' => 25,
        'world',
    ];
    foreach($ar5 as $k => $v){
        echo " $k: $v \n";
    }

    ?>
</pre>