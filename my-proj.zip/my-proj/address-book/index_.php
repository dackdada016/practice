<?php
require './parts/connect_db.php';



?>
<?php include './parts/html-head.php' ?>
<?php include './parts/navbar.php' ?>
<div class="container">
  <h2>index_</h2>
</div>
<?php include './parts/scripts.php' ?>
<?php include './parts/html-foot.php' ?>